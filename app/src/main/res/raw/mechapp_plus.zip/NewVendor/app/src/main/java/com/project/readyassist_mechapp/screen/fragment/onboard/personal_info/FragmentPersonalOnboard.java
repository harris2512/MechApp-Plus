package com.project.readyassist_mechapp.screen.fragment.onboard.personal_info;

public class FragmentPersonalOnboard {
}
