package com.project.readyassist_mechapp.applications;

public class MyApplication {
}
