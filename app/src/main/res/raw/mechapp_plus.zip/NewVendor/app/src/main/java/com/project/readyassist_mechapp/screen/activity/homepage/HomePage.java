package com.project.readyassist_mechapp.screen.activity.homepage;

import androidx.appcompat.app.AppCompatActivity;

public class HomePage extends AppCompatActivity {



}
